# qetta 디자인 디테일 — 최종 사양 (v2025-10-26)

## 1) 타이포그래피
- 한글: Pretendard Variable → 대체: Noto Sans KR, Apple SD Gothic Neo, Malgun Gothic
- 숫자: 탭너머(tabular) 활성화 (font-feature-settings: "tnum")
- 본문 14px, 인터랙션 14–16px, 헤드라인 32–40px

## 2) 색/토큰
- 배경: #0B0F14 / 승화층: #111827 / 서브: #0F172A
- 본문: #E5E7EB / 서브: #94A3B8 / 반전: #0B0F14
- 브랜드: primary #22D3EE / accent #F97316
- 심각도: CRIT #EF4444 / WARN #F59E0B / INFO #22C55E

## 3) 컴포넌트 규칙
- 카드 radius 10px, 내부 패딩 20px
- Focus ring: outline-offset 2px, 2px solid rgba(34,211,238,.7)
- 버튼: 기본 40px 높이, 아이콘간 간격 8px

## 4) 상태/피드백
- 스켈레톤: bg-white/5 + pulse 1.2s
- 에러: 토스트 상단 고정, 4초 지속, 재시도 버튼
- 업로드: 드롭존 hover시 border-white/20

## 5) 접근성
- 명암비 최소 4.5:1 (WCAG AA)
- 키보드 탐색: 탭 순서, skip link 제공
- 모션 감약: `@media (prefers-reduced-motion)` 지원

## 6) 국제화/금융
- 통화: Intl(KRW, 0자리) — `₩(n)` 헬퍼 사용
- 날짜: ko-KR medium — `date(iso)` 헬퍼
- 영업일: 서버가 제공 (UI는 표기/정렬만)

## 7) 다크모드
- 기본 dark, light 필요시 html class 토글

## 8) QA 체크리스트
- [ ] /, /consent, /upload, /verify, /result 5페이지 레이아웃 테스트
- [ ] 모바일(360px)/태블릿(768px)/데스크탑(1280px) 시각 점검
- [ ] 스크린리더 라벨/포커스 이동
- [ ] 심각도 색상이 컬러블라인드 모드에서도 구분 가능(아이콘/텍스트 조합)
