import ConsentToggle from '../../components/ConsentToggle'
export default function Page(){
  return <ConsentToggle />
}
