export default function Page(){ return <div>동의 설정(샘플)</div> }
