export default function Page(){ return <div>업로드(샘플)</div> }
