export default function Page(){ return <div>결과 요약(샘플)</div> }
