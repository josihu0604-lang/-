const fp=require('fastify-plugin'); const { verifyJwt, userFromApiKey } = require('../util');
module.exports = fp(async function(app){
  app.decorateRequest('userId', null);
  app.addHook('preHandler', async (req)=> {
    const apiKey=req.headers['x-api-key']; if(apiKey){ const id=await userFromApiKey(apiKey); if(id){ req.userId=id; return; } }
    const auth=req.headers.authorization; if(auth&&auth.startsWith('Bearer ')){ try{ const d=verifyJwt(auth.slice(7)); req.userId=d.sub; }catch{} }
  });
});
