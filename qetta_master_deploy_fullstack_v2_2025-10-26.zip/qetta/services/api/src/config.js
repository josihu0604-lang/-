const required = (k, fb) => process.env[k] ?? fb;
module.exports = {
  port: Number(required('PORT', 8080)),
  jwtSecret: required('JWT_SECRET', 'dev_jwt_secret_change_me'),
  corsOrigins: (process.env.CORS_ORIGINS||'*').split(',').map(s=>s.trim()),
  databaseUrl: process.env.DATABASE_URL,
  redisUrl: process.env.REDIS_URL,
  stripeSecret: process.env.STRIPE_SECRET_KEY,
  stripeWebhookSecret: process.env.STRIPE_WEBHOOK_SECRET,
  prices: {
    STARTER: process.env.STRIPE_PRICE_STARTER,
    PRO: process.env.STRIPE_PRICE_PRO,
    ENTERPRISE: process.env.STRIPE_PRICE_ENTERPRISE
  },
  webUrl: process.env.WEB_URL || 'http://localhost:3000'
};
